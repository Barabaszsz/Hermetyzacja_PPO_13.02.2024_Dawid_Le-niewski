public class Currency {
    private int usd;
    private int eur;
    private int gbp;
    private int chf;
    private int aed;
    private int aud;
    private int cad;
    private int bgn;

    public Currency(int usd, int eur, int gbp, int chf, int aed, int aud, int cad, int bgn) {
        this.usd = usd;
        this.eur = eur;
        this.gbp = gbp;
        this.chf = chf;
        this.aed = aed;
        this.aud = aud;
        this.cad = cad;
        this.bgn = bgn;
    }
    /********************************************************
     * nazwa funkcji: showcur
     * parametry wejściowe: usd,eur,gbp,chf,aed,aud,cad,bgn
     * wartość zwracana:Przykład:
     *                  Dolar: 4
     *                  Euro: 4
     *                  Funt: 5
     *                  Frank: 4
     *                  Dircham: 1
     *                  Dolar australijski: 2
     *                  Dolar kanadyjski: 3
     *                  Lew bułgarski: 2
     * autor: Dawid Leśniewski
     * ****************************************************/
    public void showcur(){
        System.out.println("Dolar: "+this.usd+"\nEuro: "+this.eur+"\nFunt: "+this.gbp+"\nFrank: "+this.chf+"\nDircham: "+this.aed+"\nDolar australijski: "+this.aud+"\nDolar kanadyjski: "+this.cad+"\nLew bułgarski: "+this.bgn+"\n==============");
    }
}
