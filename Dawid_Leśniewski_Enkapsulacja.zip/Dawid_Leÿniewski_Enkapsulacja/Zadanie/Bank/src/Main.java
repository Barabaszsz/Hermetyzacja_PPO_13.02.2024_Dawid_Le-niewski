public class Main {
    public static void main(String[] args) {
      User w = new User("Kacper","Kowalski",24,1234567890,"24-05-1999",456732145,"male","ul.Sasankowa 3");
      User w1 = new User("Kamil","Abacki",25,1234567893,"21-09-1998",957732145,"male","ul.Krokusowa 6");
      User w2 = new User("Stefan","Babacki",34,1234567891,"25-10-1989",556755145,"male","ul.Makowa 7");
    w.show();
    w1.show();
    w2.show();
    Bank r = new Bank("Nie posiada","Posiada","Nie posiada","Posiada","Posiada","Przestrzega","Jest bezpieczny","Nie zostawił");
    Bank r1 = new Bank("Nie posiada","NIe posiada","Posiada","Posiada","Posiada","Przestrzega","Jest bezpieczny","8/10");
    Bank r2 = new Bank("Nie posiada","Posiada","Nie posiada","Posiada","Nie posiada","Przestrzega","Jest bezpieczny","7,5/10");
    r.showbank();
    r1.showbank();
    r2.showbank();
    Currency t = new Currency(4,4,5,4,1,2,3,2);
    Currency t1 = new Currency(4,4,5,4,1,2,3,2);
    Currency t2 = new Currency(4,4,5,4,1,2,3,2);
    t.showcur();
    t1.showcur();
    t2.showcur();
    }
}