public class User {
    private String name;
    private String lastname;
    private int age;
    private int securitynumber;
    private String birthday;
    private int phonenumber;
    private String sex;
    private String street;

    public User(String name, String lastname, int age, int securitynumber, String birthday, int phonenumber, String sex, String street) {
        this.name = name;
        this.lastname = lastname;
        this.age = age;
        this.securitynumber = securitynumber;
        this.birthday = birthday;
        this.phonenumber = phonenumber;
        this.sex = sex;
        this.street = street;
    }
    /********************************************************
     * nazwa funkcji: show
     * parametry wejściowe: Imie,Nazwisko,Wiek,PESEL,Urodziny,Numer telefonu,Płeć,Ulice
     * wartość zwracana:Przykład:
     *                  Imie Stefan
     *                  Nazwisko: Babacki
     *                  Wiek: 34
     *                  PESEL: 1234567891
     *                  Urodziny: 25-10-1989
     *                  Numer telefonu: 556755145
     *                  Płeć: male
     *                  Ulica: ul.Makowa 7
     * autor: Dawid Leśniewski
     * ****************************************************/
    public void show(){
        System.out.println("Imie "+this.name+"\nNazwisko: "+this.lastname+"\nWiek: "+this.age+"\nPESEL: "+this.securitynumber+"\nUrodziny: "+this.birthday+"\nNumer telefonu: "+this.phonenumber+"\nPłeć: "+this.sex+"\nUlica: "+this.street+"\n==============");
    }
}
