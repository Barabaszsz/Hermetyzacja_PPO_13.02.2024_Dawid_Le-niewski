public class Bank {
    private String credit;
    private String account;
    private String investments;
    private String onlinebanking;
    private String finance;
    private String law;
    private String safety;
    private String reviews;

    public Bank(String credit, String account, String investments, String onlinebanking, String finance, String law, String safety, String reviews) {
        this.credit = credit;
        this.account = account;
        this.investments = investments;
        this.onlinebanking = onlinebanking;
        this.finance = finance;
        this.law = law;
        this.safety = safety;
        this.reviews = reviews;
    }
    /********************************************************
     * nazwa funkcji: showbank
     * parametry wejściowe: Kredyt,konto,Inwestycje,Bankowośc online,Finanse,Prawo,Bezpieczeństwo,Oceny
     * wartość zwracana:Przykład:
     *                  Kredyt: Nie posiada
     *                  Konto: Posiada
     *                  Inwestycje: Nie posiada
     *                  Bankowość online: Posiada
     *                  Prawo: Przestrzega
     *                  Finanse: Nie posiada
     *                  Bezpieczeństwo: Jest bezpieczny
     *                  Recenzje: 7,5/10
     * autor: Dawid Leśniewski
     * ****************************************************/
    public void showbank(){
        System.out.println("Kredyt: "+this.credit+"\nKonto: "+this.account+"\nInwestycje: "+this.investments+"\nBankowość online: "+this.onlinebanking+"\nPrawo: "+this.law+"\nFinanse: "+this.finance+"\nBezpieczeństwo: "+this.safety+"\nRecenzje: "+this.reviews+"\n=============");
    }
}
